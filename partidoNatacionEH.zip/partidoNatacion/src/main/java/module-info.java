module co.edu.uniquindio.poo.partidonatacion {
    requires javafx.controls;
    requires javafx.fxml;


    opens co.edu.uniquindio.poo.partidonatacion to javafx.fxml;
    exports co.edu.uniquindio.poo.partidonatacion;
}