package co.edu.uniquindio.poo;

public enum Categoria {
    NIÑO,
    JUVENIL,
    ADULTO,
}
